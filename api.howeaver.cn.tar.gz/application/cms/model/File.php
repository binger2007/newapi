<?php

namespace app\cms\model;

use think\Model;

class File extends Model
{
    protected $table = 'file';
}
