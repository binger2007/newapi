<?php
//处理接收到文件
require "dbConfig.php";
if ($_FILES["uploadfile"]["error"] > 0)
{
    echo "错误：" . $_FILES["uploadfile"]["error"] . "<br>";
}
else
{
    $allowedExts = array("gif", "jpeg", "jpg", "png");
     // 获取文件后缀名
    $temp = explode(".", $_FILES["uploadfile"]["name"]);   
    $extension = end($temp); 
        
    if ((($_FILES["uploadfile"]["type"] == "image/gif")
    || ($_FILES["uploadfile"]["type"] == "image/jpeg")
    || ($_FILES["uploadfile"]["type"] == "image/jpg")
    || ($_FILES["uploadfile"]["type"] == "image/pjpeg")
    || ($_FILES["uploadfile"]["type"] == "image/x-png")
    || ($_FILES["uploadfile"]["type"] == "image/png"))
    && ($_FILES["uploadfile"]["size"] < 2048000)    // 小于 2000 kb
    && in_array($extension, $allowedExts))
    {
        $name = uuid();
       $fileName = "../uploads/" .$name.".".$extension;
       move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $fileName);
       echo "/uploads/" .$name.".".$extension;
    }
   
}
 



?>