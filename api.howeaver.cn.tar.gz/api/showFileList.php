<?php 
$dir =  iconv('UTF-8','gbk',$_SERVER['DOCUMENT_ROOT'].'/歌曲');
function bianli($dir)
    {
        $files = array();
        if($head = opendir($dir))
        {
            while(($file = readdir($head)) !== false)
            {                  
                if($file != ".." && $file!="."){
                    $arr = [];
                    $arr['label'] = iconv('gbk','utf-8',$file);                   
                    if(is_dir($dir . "/" .$file)){
                         $arr_son = bianli($dir.'/'.$file);                         
                         if(count($arr_son) > 0){
                           $arr['children'] =  $arr_son;                                                     
                         }    
                         $arr['disabled'] = true;                
                     }else{
                         $arr['path'] = iconv('gbk','utf-8',$dir.'/'.$file) ;

                         }                                   
                    array_push($files,$arr);
                }
            }
        }
        closedir($head);
        return $files;
    }
    $result = bianli($dir);
    // print_r(bianli($dir));
    echo json_encode($result);

?>