<?php
echo "我的第一段 PHP 脚本！";
?>